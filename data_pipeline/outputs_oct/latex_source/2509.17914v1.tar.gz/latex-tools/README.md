# latex-tools

**A collection of useful LaTeX scripts and packages**

External resources:
* [collab](https://github.com/smarr/collab.sty) by [Stefan Marr](https://github.com/smarr)

